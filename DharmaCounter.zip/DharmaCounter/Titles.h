//
//Here you can set your own titles for all counter modes.
//The length of the title is no more than 16 characters. All characters after 16 will be cut.
//Changing the title and reuploading of the program do not change the stored counter value! 
//

#define TALLY1_TITLE ""  //Tally1 mode screen title
#define TALLY2_TITLE ""  //Tally2 mode screen title
#define TALLY3_TITLE ""  //Tally3 mode screen title
#define TALLY4_TITLE ""  //Tally4 mode screen title
#define TALLY5_TITLE ""  //Tally5 mode screen title
#define TALLY6_TITLE ""  //Tally6 mode screen title
#define TALLY7_TITLE ""  //Tally7 mode screen title
#define TALLY8_TITLE ""  //Tally8 mode screen title
#define TALLY9_TITLE ""  //Tally9 mode screen title
#define TALLY10_TITLE "" //Tally10 mode screen title
